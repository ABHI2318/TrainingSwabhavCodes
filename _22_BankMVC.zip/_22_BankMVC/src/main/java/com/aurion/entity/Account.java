package com.aurion.entity;

public class Account {
	private int Accountnumber;
	private User user;
	private Admin admin;
	private Transaction transaction;
	

}
