package com.aurion.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.aurion.service.DBConnection;



@WebServlet("/AdminLoginController")
public class AdminLoginController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adminId = request.getParameter("adminId");
        String password = request.getParameter("password");

        // Validate credentials against the database
        if (isValidAdmin(adminId, password)) {
            // Create session and redirect to admin home page
            HttpSession session = request.getSession();
            session.setAttribute("adminId", adminId);
            response.sendRedirect("adminHome.jsp");
        } else {
            // Invalid credentials, redirect back to login page with error message
            request.setAttribute("errorMessage", "Invalid Admin Credentials");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
        }
    }

    /**
     * Validates admin credentials by checking the database.
     * 
     * @param adminId The admin ID provided by the user.
     * @param password The password provided by the user.
     * @return true if the credentials are valid, false otherwise.
     */
    private boolean isValidAdmin(String adminId, String password) {
        String query = "SELECT adminId FROM Admin WHERE adminId = ? AND adminPassword = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, adminId);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Returns true if a record exists
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
