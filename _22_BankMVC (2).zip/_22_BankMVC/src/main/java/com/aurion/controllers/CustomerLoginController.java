package com.aurion.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.aurion.service.DBConnection;



@WebServlet("/CustomerLoginController")
public class CustomerLoginController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validate credentials against the database
        if (isValidCustomer(email, password)) {
            // Create session and redirect to customer home page
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            response.sendRedirect("customerHome.jsp");
        } else {
            // Invalid credentials, redirect back to login page with error message
            request.setAttribute("errorMessage", "Invalid Customer Credentials");
            request.getRequestDispatcher("customerLogin.jsp").forward(request, response);
        }
    }

    /**
     * Validates customer credentials by checking the database.
     * 
     * @param email The email provided by the user.
     * @param password The password provided by the user.
     * @return true if the credentials are valid, false otherwise.
     */
    private boolean isValidCustomer(String email, String password) {
        String query = "SELECT email FROM Customer WHERE email = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Returns true if a record exists
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
