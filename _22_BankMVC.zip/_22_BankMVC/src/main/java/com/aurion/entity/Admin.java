package com.aurion.entity;

public class Admin {

}
