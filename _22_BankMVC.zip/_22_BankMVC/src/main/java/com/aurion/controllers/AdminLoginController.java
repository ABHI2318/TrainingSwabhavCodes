package com.aurion.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginController")
public class AdminLoginController extends HttpServlet {
	private static final String admin_username="abhishek@gmail.com";
	private static final String admin_password="12345678";
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	
	  if (admin_username.equals(username) && admin_password.equals(password)) {
          response.sendRedirect("admin/home.jsp");
      } else {
          response.sendRedirect("adminLogin.jsp?error=Invalid credentials");
      }
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
